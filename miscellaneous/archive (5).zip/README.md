# Personal Finance Tracking Dataset
Synthetic dataset for budgeting and analytics.